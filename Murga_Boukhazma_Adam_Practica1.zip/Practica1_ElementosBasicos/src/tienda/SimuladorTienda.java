/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tienda;

/**
 *
 * @author Usuario1
 */
import java.util.Scanner;
public class SimuladorTienda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final double IVA = 0.21;
        
        String nombreCliente;
        char codigoSeccion;
        int cantidadUnidades;
        double precioUnidad;
        
        double subTotal;
        double totalConIva;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("¿COMO TE LLAMAS? ");
        nombreCliente = sc.nextLine();
        
        System.out.print("¿CUAL ES TU CODIGO? ");
        codigoSeccion = sc.nextLine().charAt(0);
        
        System.out.print("¿CUANTAS UNIDADES TIENES? ");
        cantidadUnidades = sc.nextInt();
        
        System.out.print("¿CUANTO CUESTA? ");
        precioUnidad = sc.nextDouble();
        
        subTotal = precioUnidad * cantidadUnidades;
        totalConIva = subTotal + (subTotal * IVA);
   
        boolean tieneDescuento = cantidadUnidades > 5 && totalConIva > 50;
        int puntosFidelidad = (int) totalConIva;    // 72

        System.out.println("¿Tiene descuento? " + tieneDescuento);
        System.out.println("Puntos de fidelidad: " + puntosFidelidad);
        System.out.printf("Subtotal: %.2f €%n", subTotal);
        System.out.printf("Total con IVA: %.2f €%n", totalConIva);
        System.out.println("¿Tiene descuento? " + tieneDescuento);
        System.out.println("Puntos de fidelidad: " + puntosFidelidad);
        
        sc.close();  
    }
    
}
